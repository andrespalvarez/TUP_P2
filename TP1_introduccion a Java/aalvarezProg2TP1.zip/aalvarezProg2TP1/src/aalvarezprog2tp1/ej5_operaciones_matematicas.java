
package aalvarezprog2tp1;

import java.util.Scanner;

public class ej5_operaciones_matematicas {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
              
        System.out.print("Ingresa un numero (A): ");
        int numA = Integer.parseInt(sc.nextLine());
        
        System.out.print("Ingresa un numero (B): ");
        int numB = Integer.parseInt(sc.nextLine());
        
        int suma=numA+numB;
        int resta1=numA-numB;
        int resta2=numB-numA;
        int multiplicacion=numA*numB;
        double division1=(double)numA/numB;
        double division2=(double)numB/numA;
        
        System.out.println("A+B= "+suma);
        System.out.println("A-B= "+resta1);
        System.out.println("B-A= "+resta2);
        System.out.println("A*B= "+multiplicacion);
        System.out.println("A/B= "+division1);
        System.out.println("B/A= "+division2);
    }
}
    