package aalvarezprog2tp1;

public class AalvarezProg2TP1 {

    public static void main(String[] args) {
       
    }
}
