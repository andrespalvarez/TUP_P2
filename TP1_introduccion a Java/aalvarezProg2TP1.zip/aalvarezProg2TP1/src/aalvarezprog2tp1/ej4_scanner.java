
package aalvarezprog2tp1;

import java.util.Scanner;

public class ej4_scanner {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingresá tu nombre: ");
        String nombre = sc.nextLine();
        
        System.out.print("Ingresá tu edad: ");
        int edad = Integer.parseInt(sc.nextLine());
        
        System.out.println("Nombre: "+nombre);
        System.out.println("Edad: "+edad);
     
    }
}
    