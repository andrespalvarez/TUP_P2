
package aalvarezprog2tp1;

import java.util.Scanner;

public class ej8_division_entera {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
              
        System.out.print("Ingresa un numero (A): ");
        int numA = Integer.parseInt(sc.nextLine());
        
        System.out.print("Ingresa un numero (B): ");
        int numB = Integer.parseInt(sc.nextLine());
        
        int division1=numA/numB;
        double division2=(double)numA/(double)numB;
        
        System.out.println("Usando enteros: A/B= "+division1);
        System.out.println("Usando nros. decimales: A/B= "+division2);
    }
}
    