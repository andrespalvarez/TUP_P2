
package aalvarezprog2tp1;

public class ej3_declaracion_variables {
    public static void main(String[] args){
        String nombre = "Julio"; 
        int edad = 35;
        double altura = 1.68;
        boolean estudiante = false; 
        
        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(altura);
        System.out.println(estudiante);
    }
}
    