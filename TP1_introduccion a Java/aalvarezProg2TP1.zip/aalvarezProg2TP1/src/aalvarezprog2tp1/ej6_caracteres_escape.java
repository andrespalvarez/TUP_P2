
package aalvarezprog2tp1;

public class ej6_caracteres_escape {
    public static void main(String[] args){

        System.out.println("Nombre: Juan Perez\nEdad: 30 años\nDireccion: \"Calle Falsa 123\"");
    }
}
    