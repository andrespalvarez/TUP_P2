
package ej8DocumentoFirmaDigitalUsuario;


public class Usuario {
    //atributos
    
    private String nombre;
    private String email;
    
    //constructor independiente

    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }
    //setters y getters

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
    
   

    
    

}
