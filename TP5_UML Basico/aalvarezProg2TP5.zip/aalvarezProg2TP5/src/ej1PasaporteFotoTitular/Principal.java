
package ej1PasaporteFotoTitular;

public class Principal {

    public static void main(String[] args) {
       
    }
    
}
