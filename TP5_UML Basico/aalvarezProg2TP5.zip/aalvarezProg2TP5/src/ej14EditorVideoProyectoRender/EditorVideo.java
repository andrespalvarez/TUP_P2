
package ej14EditorVideoProyectoRender;


public class EditorVideo {
    //metodo que llama al Render
    
    public void exportar( String formato){
        Render render1 = new Render(formato); //instancia un nuevo Render
        //codigo que ejecuta el editor utilizando render1.getFormato()
    }
}
