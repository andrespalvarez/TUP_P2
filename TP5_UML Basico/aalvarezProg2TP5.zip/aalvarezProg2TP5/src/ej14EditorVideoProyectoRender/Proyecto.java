
package ej14EditorVideoProyectoRender;


public class Proyecto {
    //atributos
    private String nombre;
    private double duracion;
        
    //constructor indepediente

    public Proyecto(String nombre, double duracion) {
        this.nombre = nombre;
        this.duracion = duracion;
    }
    //getters

    public String getNombre() {
        return nombre;
    }

    public double getDuracion() {
        return duracion;
    }
    

    

    
    
    
}
