
package ej13GeneradorQRUsuarioCodigoQR;



public class Usuario {
    //atributos
    private String nombre;
    private String email;
        
    //constructor indepediente

    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }
    //getters

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
    

    
    
    
}
