
package ej11ReproductorCancionArtista;


public class Reproductor {
    //metodo que llama a la cancion
    
    public void reproducir( Cancion cancion1){
        //codigo que ejecuta el reproductor utilizando cancion1.getTitulo()
    }
}
