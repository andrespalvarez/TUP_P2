
package ej12ImpuestoContribuyenteCalculadora;



public class Calculadora {
    //metodo que llama al impuesto
    
    public void calcular(Impuesto impuesto1){
        //codigo que ejecuta la calculadora utilizando impuesto1.getMonto()
    }
}
