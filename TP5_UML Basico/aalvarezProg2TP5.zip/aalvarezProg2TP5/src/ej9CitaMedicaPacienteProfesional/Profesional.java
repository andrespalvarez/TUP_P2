
package ej9CitaMedicaPacienteProfesional;


public class Profesional {
    //atributos
    private String nombre;
    private String especialidad;
        
    //constructor indepediente

    public Profesional(String nombre, String especialidad) {
        this.nombre = nombre;
        this.especialidad = especialidad;
    }
    //setters y getters

    public String getNombre() {
        return nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }
    
    
    
    
    
}
